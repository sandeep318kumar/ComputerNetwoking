#include<stdio.h>
#include<unistd.h>
int main()
{
    printf("Now I am in program 4 \n");
    // printf("Going to program 3\n");
    // const char *a[] = {"./p2", NULL};
    // execv(a[0], 0); 
    return 0;
}